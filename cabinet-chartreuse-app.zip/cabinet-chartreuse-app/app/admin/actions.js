'use server';

import crypto from 'crypto';
import { cookies } from 'next/headers';
import { revalidatePath } from 'next/cache';
import { getBottles, saveBottles, uploadPhoto } from '@/lib/store';
import { createSessionCookieValue, isValidSession, SESSION_COOKIE_NAME, SESSION_MAX_AGE } from '@/lib/auth';

async function requireAdmin() {
  const cookieStore = await cookies();
  const session = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  if (!isValidSession(session)) {
    throw new Error('Non autorisé');
  }
}

export async function login(password) {
  if (!process.env.ADMIN_PASSWORD || password !== process.env.ADMIN_PASSWORD) {
    throw new Error('Mot de passe incorrect');
  }
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE_NAME, createSessionCookieValue(), {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    maxAge: SESSION_MAX_AGE,
    path: '/'
  });
}

export async function logout() {
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE_NAME, '', { maxAge: 0, path: '/' });
}

function readFields(formData) {
  return {
    reference: formData.get('reference')?.toString().trim() || '',
    name: formData.get('name')?.toString().trim() || '',
    tier: formData.get('tier')?.toString() || 'rare',
    year: formData.get('year')?.toString().trim() || '',
    level: formData.get('level')?.toString().trim() || '',
    description: formData.get('description')?.toString().trim() || '',
    price: formData.get('price') ? Number(formData.get('price')) : null
  };
}

export async function addBottle(formData) {
  await requireAdmin();
  const bottles = await getBottles();

  let image_url = null;
  const file = formData.get('image');
  if (file && typeof file === 'object' && file.size > 0) {
    image_url = await uploadPhoto(file);
  }

  bottles.unshift({
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    ...readFields(formData),
    image_url,
    sold: false
  });

  await saveBottles(bottles);
  revalidatePath('/');
  revalidatePath('/admin');
}

export async function updateBottle(id, formData) {
  await requireAdmin();
  const bottles = await getBottles();
  const idx = bottles.findIndex((b) => b.id === id);
  if (idx === -1) throw new Error('Bouteille introuvable');

  let image_url = bottles[idx].image_url || null;
  const file = formData.get('image');
  if (file && typeof file === 'object' && file.size > 0) {
    image_url = await uploadPhoto(file);
  }

  bottles[idx] = {
    ...bottles[idx],
    ...readFields(formData),
    image_url
  };

  await saveBottles(bottles);
  revalidatePath('/');
  revalidatePath('/admin');
}

export async function toggleSold(id, sold) {
  await requireAdmin();
  const bottles = await getBottles();
  const idx = bottles.findIndex((b) => b.id === id);
  if (idx === -1) return;
  bottles[idx].sold = sold;
  await saveBottles(bottles);
  revalidatePath('/');
  revalidatePath('/admin');
}

export async function deleteBottle(id) {
  await requireAdmin();
  const bottles = await getBottles();
  await saveBottles(bottles.filter((b) => b.id !== id));
  revalidatePath('/');
  revalidatePath('/admin');
}
