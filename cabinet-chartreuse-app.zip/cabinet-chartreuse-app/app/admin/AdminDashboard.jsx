'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { addBottle, updateBottle, deleteBottle, toggleSold, logout } from './actions';

const emptyForm = {
  reference: '',
  name: '',
  tier: 'rare',
  year: '',
  level: '',
  description: '',
  price: '',
  image_url: ''
};

export default function AdminDashboard({ bottles }) {
  const router = useRouter();
  const [editingId, setEditingId] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleAdd(formData) {
    setError('');
    setSaving(true);
    try {
      await addBottle(formData);
      setShowAddForm(false);
      router.refresh();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleUpdate(id, formData) {
    setError('');
    setSaving(true);
    try {
      await updateBottle(id, formData);
      setEditingId(null);
      router.refresh();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id, name) {
    if (!window.confirm(`Supprimer définitivement "${name}" ?`)) return;
    try {
      await deleteBottle(id);
      router.refresh();
    } catch (e) {
      setError(e.message);
    }
  }

  async function handleToggleSold(id, sold) {
    try {
      await toggleSold(id, sold);
      router.refresh();
    } catch (e) {
      setError(e.message);
    }
  }

  async function handleLogout() {
    await logout();
    router.refresh();
  }

  return (
    <div className="admin-shell">
      <header className="admin-header">
        <h1>Tableau de bord</h1>
        <button className="btn btn-ghost" onClick={handleLogout}>Se déconnecter</button>
      </header>

      {error && <p className="admin-error">{error}</p>}

      <div className="admin-toolbar">
        <button className="btn btn-primary" onClick={() => setShowAddForm((v) => !v)}>
          {showAddForm ? 'Annuler' : '+ Ajouter une bouteille'}
        </button>
        <a className="btn btn-ghost" href="/" target="_blank" rel="noopener">Voir le site</a>
      </div>

      {showAddForm && (
        <form action={handleAdd} className="bottle-form">
          <BottleFields defaults={emptyForm} />
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Enregistrement…' : 'Enregistrer la bouteille'}
          </button>
        </form>
      )}

      <ul className="admin-list">
        {bottles.map((b) => (
          <li key={b.id} className="admin-item">
            {editingId === b.id ? (
              <form action={(fd) => handleUpdate(b.id, fd)} className="bottle-form">
                <BottleFields defaults={b} />
                <div className="admin-item-actions">
                  <button className="btn btn-primary" type="submit" disabled={saving}>
                    {saving ? 'Enregistrement…' : 'Enregistrer'}
                  </button>
                  <button className="btn btn-ghost" type="button" onClick={() => setEditingId(null)}>
                    Annuler
                  </button>
                </div>
              </form>
            ) : (
              <>
                <div className="admin-item-main">
                  <span className={`seal-tag ${b.tier}`}>{b.tier === 'rare' ? 'RARE' : 'RÉCENT'}</span>
                  <div>
                    <strong>{b.name}</strong>
                    <p className="admin-item-meta">
                      N° {b.reference} — {b.year} — {b.price ? `${b.price} €` : 'prix non renseigné'}
                      {b.sold ? ' — VENDUE' : ''}
                    </p>
                  </div>
                </div>
                <div className="admin-item-actions">
                  <button className="btn btn-ghost" onClick={() => handleToggleSold(b.id, !b.sold)}>
                    {b.sold ? 'Marquer disponible' : 'Marquer vendue'}
                  </button>
                  <button className="btn btn-ghost" onClick={() => setEditingId(b.id)}>
                    Modifier
                  </button>
                  <button className="btn btn-ghost btn-danger" onClick={() => handleDelete(b.id, b.name)}>
                    Supprimer
                  </button>
                </div>
              </>
            )}
          </li>
        ))}
        {bottles.length === 0 && <p>Aucune bouteille pour le moment. Ajoutez la première ci-dessus.</p>}
      </ul>
    </div>
  );
}

function BottleFields({ defaults }) {
  return (
    <div className="bottle-form-grid">
      <label>
        Numéro (référence)
        <input name="reference" defaultValue={defaults.reference} placeholder="CH-1971" required />
      </label>
      <label>
        Nom de la bouteille
        <input name="name" defaultValue={defaults.name} placeholder="Chartreuse Verte, bouchon liège" required />
      </label>
      <label>
        Catégorie
        <select name="tier" defaultValue={defaults.tier}>
          <option value="rare">Rare</option>
          <option value="recent">Récente</option>
        </select>
      </label>
      <label>
        Année / millésime
        <input name="year" defaultValue={defaults.year} placeholder="1988" required />
      </label>
      <label>
        Niveau de remplissage
        <input name="level" defaultValue={defaults.level} placeholder="Niveau plein" />
      </label>
      <label>
        Prix (€)
        <input name="price" type="number" step="1" defaultValue={defaults.price || ''} placeholder="890" />
      </label>
      <label className="full-width">
        Photo {defaults.image_url ? '(laisser vide pour garder la photo actuelle)' : '(optionnel)'}
        <input name="image" type="file" accept="image/*" />
      </label>
      <label className="full-width">
        Description
        <textarea name="description" defaultValue={defaults.description} rows={3} placeholder="État, provenance, particularités…" />
      </label>
    </div>
  );
}
