import { cookies } from 'next/headers';
import { isValidSession, SESSION_COOKIE_NAME } from '@/lib/auth';
import { getBottles } from '@/lib/store';
import LoginForm from './LoginForm';
import AdminDashboard from './AdminDashboard';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const cookieStore = await cookies();
  const session = cookieStore.get(SESSION_COOKIE_NAME)?.value;

  if (!isValidSession(session)) {
    return <LoginForm />;
  }

  const bottles = await getBottles();

  return <AdminDashboard bottles={bottles} />;
}
