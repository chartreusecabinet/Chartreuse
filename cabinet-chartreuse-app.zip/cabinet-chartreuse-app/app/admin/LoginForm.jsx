'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { login } from './actions';

export default function LoginForm() {
  const router = useRouter();
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState('idle'); // idle | loading | error

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus('loading');
    try {
      await login(password);
      router.refresh();
    } catch (e) {
      setStatus('error');
    }
  }

  return (
    <div className="admin-login">
      <form className="admin-login-card" onSubmit={handleSubmit}>
        <span className="seal-mini">ADMIN</span>
        <h1>Espace privé</h1>
        <p>Entrez le mot de passe pour accéder au tableau de bord.</p>

        <input
          type="password"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
            setStatus('idle');
          }}
          placeholder="Mot de passe"
          autoFocus
        />

        <button className="btn btn-primary" type="submit" disabled={status === 'loading'}>
          {status === 'loading' ? 'Vérification…' : 'Se connecter'}
        </button>

        {status === 'error' && <p className="admin-error">Mot de passe incorrect.</p>}
      </form>
    </div>
  );
}
