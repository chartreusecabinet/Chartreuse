'use client';

import { useState } from 'react';

export default function AgeGate({ children }) {
  const [confirmed, setConfirmed] = useState(false);

  if (!confirmed) {
    return (
      <div className="age-gate">
        <div className="age-card">
          <span className="seal-mini">18+</span>
          <h2>Avant d'entrer dans le cabinet</h2>
          <p>
            Ce site présente des boissons alcoolisées destinées à des collectionneurs majeurs.
            Confirmez votre âge pour continuer.
          </p>
          <div className="age-actions">
            <button className="btn btn-primary" onClick={() => setConfirmed(true)}>
              J'ai 18 ans ou plus
            </button>
            <a className="btn btn-ghost" href="https://www.alcool-info-service.fr" target="_blank" rel="noopener noreferrer">
              Je suis mineur
            </a>
          </div>
          <p className="age-legal">L'abus d'alcool est dangereux pour la santé. À consommer avec modération.</p>
        </div>
      </div>
    );
  }

  return children;
}
