'use client';

import { useState } from 'react';

export default function BottleGrid({ bottles }) {
  const [filter, setFilter] = useState('rare');

  const visible = filter === 'all' ? bottles : bottles.filter((b) => b.tier === filter);

  return (
    <>
      <div className="tabs" role="tablist">
        {[
          { key: 'rare', label: 'Bouteilles rares' },
          { key: 'recent', label: 'Cuvées récentes' },
          { key: 'all', label: 'Tout voir' }
        ].map((t) => (
          <button
            key={t.key}
            className={`tab ${filter === t.key ? 'active' : ''}`}
            role="tab"
            aria-selected={filter === t.key}
            onClick={() => setFilter(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="grid">
        {visible.length === 0 && <p className="empty-collection">Aucune bouteille dans cette catégorie pour le moment.</p>}
        {visible.map((b) => (
          <article className="bottle-card" key={b.id} data-tier={b.tier}>
            <div className="card-top">
              <span className="bottle-num">N° {b.reference}</span>
              <span className={`seal ${b.tier}`}>
                {b.tier === 'rare' ? 'RARE' : 'RÉCENT'}
                <br />
                {b.year}
              </span>
            </div>

            {b.image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img className="bottle-photo" src={b.image_url} alt={b.name} />
            ) : (
              <div className="bottle-illustration">
                <svg viewBox="0 0 60 140">
                  <path d="M22 6 h16 v22 c0 5 6 7 9 13 c5 8 8 16 8 26 v58 c0 6 -5 11 -11 11 H16 c-6 0 -11 -5 -11 -11 V67 c0 -10 3 -18 8 -26 c3 -6 9 -8 9 -13 Z" />
                </svg>
              </div>
            )}

            <h3>
              {b.name}
              {b.sold && <span className="sold-badge">Vendue</span>}
            </h3>
            <p className="bottle-meta">
              {b.year} — {b.level || 'niveau non précisé'}
            </p>
            <p className="bottle-desc">{b.description}</p>

            <div className="card-bottom">
              <span className="price">{b.price ? `${b.price} €` : 'Sur demande'}</span>
              {!b.sold && (
                <a href={`mailto:${process.env.NEXT_PUBLIC_CONTACT_EMAIL}?subject=Bouteille%20${encodeURIComponent(b.reference)}`}>
                  Je suis intéressé
                </a>
              )}
            </div>
          </article>
        ))}
      </div>
    </>
  );
}
