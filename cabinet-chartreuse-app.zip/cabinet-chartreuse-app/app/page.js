import { getBottles } from '@/lib/store';
import AgeGate from './components/AgeGate';
import BottleGrid from './components/BottleGrid';

export const revalidate = 0;

const wantedItems = [
  {
    title: 'Tarragone, toutes années',
    desc: 'Verte ou Jaune, verre moulé, avec ou sans boîte.'
  },
  {
    title: 'VEP antérieures à 1990',
    desc: "Niveau haut exigé, boîte d'origine appréciée mais non indispensable."
  },
  {
    title: 'Flacons de collection familiale',
    desc: 'Bouteilles héritées ou oubliées en cave, même sans certitude sur le millésime : je peux vous aider à les identifier.'
  }
];

export default async function HomePage() {
  const bottles = await getBottles();

  const contactEmail = process.env.NEXT_PUBLIC_CONTACT_EMAIL;

  return (
    <AgeGate>
      <div className="site">
        <header className="nav">
          <a href="#top" className="wordmark">
            Cabinet <span>Chartreuse</span>
          </a>
          <nav className="nav-links">
            <a href="#heritage">Histoire</a>
            <a href="#collection">Collection</a>
            <a href="#recherche">Je recherche</a>
            <a href="#provenance">Provenance</a>
            <a href="#acheter">Comment acheter</a>
            <a href="#contact">Contact</a>
          </nav>
        </header>

        <main>
          {/* HERO */}
          <section className="hero" id="top">
            <div className="hero-inner">
              <p className="eyebrow">Un manuscrit remis en 1605, un secret gardé depuis plus de quatre siècles</p>
              <h1>
                Le vert et le jaune
                <br />
                ne s&apos;improvisent pas.
              </h1>
              <p className="hero-sub">
                Collectionneur passionné, je cède une partie de ma collection personnelle de Chartreuse, des
                cuvées récentes aux flacons anciens, et je suis toujours à la recherche de nouveaux flacons pour
                la compléter. Aucune activité commerciale ici, juste des échanges entre passionnés d&apos;un
                patrimoine unique.
              </p>
              <div className="hero-actions">
                <a href="#collection" className="btn btn-primary">Voir la collection</a>
                <a href="#acheter" className="btn btn-ghost">Comment acheter</a>
              </div>
            </div>
            <div className="hero-glyph" aria-hidden="true">
              <svg viewBox="0 0 200 400" className="bottle-hero">
                <path d="M85 20 h30 v45 c0 8 8 12 14 20 c10 12 16 28 16 48 v230 c0 10 -8 18 -18 18 H73 c-10 0 -18 -8 -18 -18 V133 c0 -20 6 -36 16 -48 c6 -8 14 -12 14 -20 Z" />
              </svg>
            </div>
          </section>

          {/* HISTOIRE */}
          <section className="heritage" id="heritage">
            <div className="section-head">
              <h2>Quatre siècles avant la première goutte</h2>
              <p>
                Avant d&apos;être une bouteille de collection, la Chartreuse est un secret transmis, presque
                perdu, puis retrouvé. Voici les dates qui comptent.
              </p>
            </div>
            <ol className="timeline">
              <li>
                <span className="tl-year">1605</span>
                <div>
                  <h3>Le manuscrit</h3>
                  <p>
                    À Paris, un maréchal de France remet aux moines chartreux un texte énigmatique : la formule
                    d&apos;un élixir de longue vie, composée de plantes, de racines et d&apos;écorces. Trop
                    complexe, elle dort pendant plus d&apos;un siècle.
                  </p>
                </div>
              </li>
              <li>
                <span className="tl-year">1764</span>
                <div>
                  <h3>L&apos;élixir prend forme</h3>
                  <p>
                    Un frère apothicaire parvient enfin à fixer la recette. L&apos;Élixir Végétal de la Grande
                    Chartreuse voit le jour, et n&apos;a pratiquement pas changé depuis.
                  </p>
                </div>
              </li>
              <li>
                <span className="tl-year">1840</span>
                <div>
                  <h3>Naissance de la liqueur de santé</h3>
                  <p>
                    De l&apos;élixir dérive une version plus digestive et plus accessible : la Chartreuse Verte,
                    bientôt suivie de la Jaune, plus douce.
                  </p>
                </div>
              </li>
              <li>
                <span className="tl-year">Aujourd&apos;hui</span>
                <div>
                  <h3>Un secret toujours gardé</h3>
                  <p>
                    La recette, faite de 130 plantes, reste connue d&apos;à peine deux moines à la fois.
                    C&apos;est ce mystère, autant que le goût, que les collectionneurs cherchent à posséder.
                  </p>
                </div>
              </li>
            </ol>
          </section>

          {/* COLLECTION */}
          <section className="collection" id="collection">
            <div className="section-head">
              <h2>La collection</h2>
              <p>Chaque flacon est décrit tel qu&apos;il est, avec son numéro, son niveau et son état de conservation.</p>
            </div>
            <BottleGrid bottles={bottles || []} />
          </section>

          {/* CE QUE JE RECHERCHE */}
          <section className="recherche" id="recherche">
            <div className="section-head">
              <h2>Ce que je recherche</h2>
              <p>
                La collection se complète aussi par l&apos;achat. Si vous possédez l&apos;un de ces flacons, ou
                tout autre millésime ancien, je suis preneur.
              </p>
            </div>
            <div className="wanted-list">
              {wantedItems.map((item) => (
                <div className="wanted-item" key={item.title}>
                  <span className="wanted-tag">Recherché</span>
                  <h3>{item.title}</h3>
                  <p>{item.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* PROVENANCE */}
          <section className="provenance" id="provenance">
            <div className="provenance-text">
              <h2>Provenance & authenticité</h2>
              <p>
                Aucune bouteille n&apos;est mise en vente sans vérification. Chaque flacon ancien passe par le
                même contrôle avant d&apos;être proposé, et je documente ce que je peux prouver, sans jamais
                habiller une lacune en certitude.
              </p>
              <ol className="verif-steps">
                <li>
                  <span className="num">01</span>
                  <div>
                    <strong>Lecture de l&apos;étiquette et du bouchon</strong>
                    <p>Millésime, imprimerie, capsule d&apos;origine : je compare aux références connues pour la période.</p>
                  </div>
                </li>
                <li>
                  <span className="num">02</span>
                  <div>
                    <strong>Niveau et couleur</strong>
                    <p>Je mesure le niveau de liquide et note toute évolution de couleur due à l&apos;âge.</p>
                  </div>
                </li>
                <li>
                  <span className="num">03</span>
                  <div>
                    <strong>Historique de conservation</strong>
                    <p>Origine d&apos;achat, durée en cave, exposition à la lumière : tout ce que je sais est écrit dans la fiche.</p>
                  </div>
                </li>
              </ol>
            </div>
            <div className="provenance-card">
              <p className="quote-mark">&quot;</p>
              <p>
                Une bouteille de collection ne vaut que ce que son histoire peut prouver. Le reste n&apos;est
                que de l&apos;étiquette.
              </p>
            </div>
          </section>

          {/* COMMENT ACHETER */}
          <section className="acheter" id="acheter">
            <div className="section-head">
              <h2>Comment acheter</h2>
              <p>Pas de panier ni de paiement en ligne : chaque échange se fait directement, par email.</p>
            </div>
            <div className="steps-row">
              <div className="step-card">
                <span className="step-index">1</span>
                <h3>Vous m&apos;écrivez</h3>
                <p>En précisant le numéro de la bouteille qui vous intéresse.</p>
              </div>
              <div className="step-card">
                <span className="step-index">2</span>
                <h3>On échange sur le flacon</h3>
                <p>Photos supplémentaires, état détaillé, historique : je réponds à toutes vos questions avant toute décision.</p>
              </div>
              <div className="step-card">
                <span className="step-index">3</span>
                <h3>Remise ou envoi sécurisé</h3>
                <p>Remise en main propre ou envoi assuré selon la valeur du flacon, réglé par virement à réception d&apos;accord.</p>
              </div>
            </div>
          </section>

          {/* CONTACT */}
          <section className="contact" id="contact">
            <div className="contact-inner">
              <h2>Une bouteille vous intéresse, ou vous en avez une à me proposer ?</h2>
              <p>
                Que ce soit pour un flacon de la collection ou pour me proposer une bouteille que vous
                souhaitez céder, écrivez-moi. Je réponds sous 48 heures.
              </p>
              <div className="contact-actions">
                <a
                  className="btn btn-primary"
                  href={`mailto:${contactEmail}?subject=Une%20bouteille%20de%20la%20collection`}
                >
                  {contactEmail}
                </a>
              </div>
            </div>
          </section>
        </main>

        <footer className="site-footer">
          <p>
            Cabinet Chartreuse — collection personnelle d&apos;un particulier, cédée et complétée de façon
            occasionnelle. Aucune activité commerciale, hors production et hors affiliation avec la Chartreuse
            Diffusion ou les Pères Chartreux.
          </p>
          <p className="legal">
            Échanges réservés aux personnes majeures. L&apos;abus d&apos;alcool est dangereux pour la santé, à
            consommer avec modération.
          </p>
        </footer>
      </div>
    </AgeGate>
  );
}
